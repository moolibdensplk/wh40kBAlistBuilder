#!/bin/bash

cp -Rvf wh40kbalistbuilder ${HOME}/
echo "Faction data files have been copied to : ${HOME}/wh40kbalistbuilder/DataFiles/"
ls -l ${HOME}/wh40kbalistbuilder/DataFiles/



