INSTALL PROCESS:

1. DRAG AND DROP the .app package to Applications folder.

2. Open iTerm and execute the install.sh, to COPY the data files.
(run this command in the iterm: )

bash install.sh



