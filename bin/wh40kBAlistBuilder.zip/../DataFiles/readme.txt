THIS Folder is for keeping JSON fiels with the faction data.

Due to legal reasons, JSON files are not included.


run this on your mac before running the app:

mkdir -p ${USER}/wh40kbalistbuilder/DataFiles

Then copy / drag and drop the DATA FILES (JSON) to that folder

cp -vf *.json ${USER}/wh40kbalistbuilder/DataFiles/


